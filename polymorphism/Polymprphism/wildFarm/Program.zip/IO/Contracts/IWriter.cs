﻿using System;
using System.Collections.Generic;
using System.Text;

namespace wildFarm.IO
{
    public interface IWriter
    {
        void Write(string text);
    }
}
