﻿using System;
using wildFarm.Core;

namespace wildFarm
{
    class Program
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
