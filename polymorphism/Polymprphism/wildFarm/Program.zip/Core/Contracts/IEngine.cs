﻿using System;
using System.Collections.Generic;
using System.Text;

namespace wildFarm.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
