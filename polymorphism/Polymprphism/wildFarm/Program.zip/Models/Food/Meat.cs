﻿using System;
using System.Collections.Generic;
using System.Text;

namespace wildFarm.Models
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
