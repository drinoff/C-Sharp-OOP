﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Text;

namespace wildFarm.Models
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
