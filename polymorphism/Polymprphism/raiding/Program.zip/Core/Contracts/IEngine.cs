﻿using System;
using System.Collections.Generic;
using System.Text;

namespace raiding.Core
{
    public interface IEngine
    {
        void Run();
    }
}
