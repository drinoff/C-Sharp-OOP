﻿using System;
using System.Collections.Generic;
using System.Text;

namespace raiding.IO.Contracts
{
    public interface IWriter
    {
        void Write(string text);
    }
}
