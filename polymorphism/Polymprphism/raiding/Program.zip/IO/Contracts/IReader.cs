﻿using System;
using System.Collections.Generic;
using System.Text;

namespace raiding.IO.Contracts
{
    public interface IReader
    {
        string Read();
    }
}
