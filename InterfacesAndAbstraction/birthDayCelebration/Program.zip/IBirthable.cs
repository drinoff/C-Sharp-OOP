﻿using System;
using System.Collections.Generic;
using System.Text;

namespace birthDayCelebration
{ 
    public interface IBirthable
    {
        public string Birthdate { get; set; }
    }
}
