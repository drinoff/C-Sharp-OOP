﻿using System;
using System.Collections.Generic;
using System.Text;

namespace birthDayCelebration
{
    public interface INameable
    {
        public string Name { get; set; }
    }
}
