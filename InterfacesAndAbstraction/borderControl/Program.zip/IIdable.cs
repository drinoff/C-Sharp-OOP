﻿using System;
using System.Collections.Generic;
using System.Text;

namespace borderControl
{
    interface IIdable
    {
        public string Id { get; set; }
    }
}
